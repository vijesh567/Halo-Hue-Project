# Halo & Hue - Beauty E-commerce Homepage (UI/UX Assignment)

Files
- index.html  page structure (tabs: Desktop, Mobile, Wireframes, Design approach)
- style.css   all styles (responsive via container queries)
- script.js   renders the homepage and wireframes, handles tabs

Run in VS Code
1. Open this folder in VS Code (File > Open Folder).
2. Install the 'Live Server' extension.
3. Right-click index.html > Open with Live Server.
(Or just double-click index.html. Internet is needed for Google Fonts.)

Deploy free: drag the folder into app.netlify.com/drop
