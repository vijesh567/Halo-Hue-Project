var P=[["Barrier Repair Cream","Skincare · 50 ml","$28","#f4d6dc","Best seller"],["Velvet Tint Lip Colour","Makeup · 4 shades","$18","#f8c9c2","New"],["Scalp Reset Shampoo","Haircare · 250 ml","$22","#dce8f5",""],["Vitamin C Glow Serum","Skincare · 30 ml","$34","#d9eac9","-20%"]];
var C=["#f4d6dc","#f8c9c2","#dce8f5","#d9eac9"],CN=["Skincare","Makeup","Haircare","Body &amp; bath"];
function bots(c){return '<i class="bt" style="--c:'+c+';left:18%;width:26%;height:46%;filter:brightness(.9)"></i><i class="bt" style="--c:#fff;left:42%;width:22%;height:62%"></i><i class="bt" style="--c:'+c+';left:64%;width:18%;height:38%;filter:brightness(.85)"></i>'}
var I=function(n){return '<svg><use href="#'+n+'"/></svg>'};
var site='<div class="ann">Free delivery on orders over $40</div>'+
'<div class="hd"><a class="burger" href="#" aria-label="Menu">'+I('me')+'</a><a class="logo" href="#">Halo <i>&amp;</i> Hue</a>'+
'<div class="srch" style="grid-column:2"><svg width="20" height="20" style="stroke:#6a617a;fill:none;stroke-width:1.8"><use href="#se"/></svg>Search serums, lipsticks, shampoo</div>'+
'<div class="ic"><a class="u" href="#" aria-label="Profile">'+I('us')+'</a><a class="bag" href="#" aria-label="Bag, 2 items">'+I('ba')+'<b>2</b></a></div></div>'+
'<nav class="nav"><a href="#">Skincare</a><a href="#">Makeup</a><a href="#">Haircare</a><a href="#">Body</a><a href="#">Gifts</a><a class="sale" href="#">Sale</a></nav>'+
'<div class="hero"><div><h1>Skin that feels rested.</h1><p>Our gentle barrier-repair range is back in stock. Fragrance-free and made for daily use.</p><a class="btn" href="#">Shop skincare</a><a class="btn alt" href="#">Take the skin quiz</a></div><div class="hv">'+bots('#c9a7e8')+'</div></div>'+
'<div class="sec"><h2>Shop by category</h2><p class="sub">Find what you need in two taps.</p><div class="cats">'+CN.map(function(n,i){return '<a class="cat" href="#" style="--c:'+C[i]+'">'+n+'</a>'}).join('')+'</div></div>'+
'<div class="sec"><div class="row"><div><h2>Best sellers</h2><p class="sub">The products our customers reorder most.</p></div><a href="#">View all</a></div><div class="grid">'+
P.map(function(p){return '<a class="pc" href="#"><div class="pv" style="--c:'+p[3]+'">'+(p[4]?'<span class="tag">'+p[4]+'</span>':'')+bots('#fff')+'</div><h3>'+p[0]+'</h3><small>'+p[1]+'</small><div class="pr"><span>'+p[2]+'</span><button class="add">Add to bag</button></div></a>'}).join('')+'</div></div>'+
'<div class="sec"><div class="promo"><div class="pm a"><h3>20% off all serums</h3><p>This week only. Discount applies at checkout.</p><a class="btn" href="#">Shop the offer</a></div><div class="pm b"><h3>New: Scalp care</h3><p>Three new haircare launches.</p><a class="btn" href="#">See what’s new</a></div></div></div>'+
'<footer class="ft"><div class="fg"><div><div class="logo" style="color:#fff;font-size:24px">Halo &amp; Hue</div><p style="margin-top:8px;font-size:14px">Simple, kind beauty for every day.</p><div class="soc"><span>IG</span><span>YT</span><span>TT</span></div></div>'+
'<div><h4>Shop</h4><ul><li>Skincare</li><li>Makeup</li><li>Haircare</li></ul></div><div><h4>Help</h4><ul><li>Contact</li><li>Delivery</li><li>Returns</li></ul></div><div><h4>Company</h4><ul><li>About</li><li>Ingredients</li><li>Careers</li></ul></div></div><p class="fine">© 2026 Halo &amp; Hue. Demo design with dummy content.</p></footer>';
d.innerHTML=site;m.innerHTML=site;
var B=function(t,c){return '<div class="b '+(c||'')+'">'+t+'</div>'};
var pc=[1,2,3,4].map(function(){return '<div class="pcw">'+B('Image','x')+B('Product name')+B('Price + Add')+'</div>'}).join('');
function wf(){return '<div class="w">'+B('Announcement bar')+
'<div class="l" style="margin-top:8px">1 Header</div><div class="r de">'+B('Logo').replace('class="b','style="flex:.5" class="b')+B('Search bar')+B('Profile · Bag').replace('class="b','style="flex:.5" class="b')+'</div>'+
'<div class="r mo">'+B('☰').replace('class="b','style="flex:.3" class="b')+B('Logo')+B('Bag').replace('class="b','style="flex:.3" class="b')+'</div><div class="r mo">'+B('Search bar')+'</div>'+
'<div class="r">'+B('Category menu: Skincare | Makeup | Haircare | Gifts | Sale')+'</div>'+
'<div class="l">2 Hero</div><div class="r"><div>'+B('Headline + subtext')+'<div style="height:8px"></div>'+B('CTA button')+'</div>'+B('Featured product image','x').replace('class="b','style="min-height:130px" class="b')+'</div>'+
'<div class="l">3 Categories</div><div class="g4">'+[1,2,3,4].map(function(){return B('Category tile','x')}).join('')+'</div>'+
'<div class="l">4 Best sellers (image, name, price, CTA)</div><div class="g4">'+pc+'</div>'+
'<div class="l">5 Offers</div><div class="r">'+B('Discount banner + CTA','x')+B('New arrivals banner','x')+'</div>'+
'<div class="l">6 Footer</div><div class="r">'+B('About')+B('Contact')+B('Help')+B('Social icons')+'</div></div>'}
wd.innerHTML=wf();wm.innerHTML=wf();
var tb=document.querySelectorAll('.tabs button');
tb.forEach(function(b){b.onclick=function(){tb.forEach(function(x){x.setAttribute('aria-selected',x==b)});document.querySelectorAll('.pane').forEach(function(p){p.classList.toggle('on',p.id==b.dataset.t)})}});
